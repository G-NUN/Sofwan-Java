package restaurentin;

public class RMS
{
	public static void main(String[] args) {
		Controller cController = new Controller();
		cController.mainLoop();
	}
}
